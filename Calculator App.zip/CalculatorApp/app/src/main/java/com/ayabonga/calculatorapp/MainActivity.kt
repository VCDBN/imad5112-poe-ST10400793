package com.ayabonga.calculatorapp


import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private lateinit var number1EditText: EditText
    private lateinit var number2EditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var addButton: Button
    private lateinit var subtractButton: Button
    private lateinit var divideButton: Button
    private lateinit var clearButton: Button
    private lateinit var multiplyButton: Button
    private lateinit var sqrtButton: Button
    private lateinit var powerButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements
        number1EditText = findViewById(R.id.editNum1)
        number2EditText = findViewById(R.id.editNum2)
        resultTextView = findViewById(R.id.textView)

        addButton = findViewById(R.id.addIt)
        subtractButton = findViewById(R.id.subtract)
        divideButton = findViewById(R.id.divide)
        clearButton = findViewById(R.id.cleartext)
        multiplyButton = findViewById(R.id.multiply)
        sqrtButton = findViewById(R.id.sqrtButton)
        powerButton = findViewById(R.id.powerButton)

        // Set click listeners for buttons
        addButton.setOnClickListener { performOperation("+") }
        subtractButton.setOnClickListener { performOperation("-") }
        divideButton.setOnClickListener { performOperation("/") }
        clearButton.setOnClickListener { clearFields() }
        multiplyButton.setOnClickListener { performOperation("*") }
        sqrtButton.setOnClickListener { calculateSquareRoot() }
        powerButton.setOnClickListener { calculatePower() }
    }

    private fun performOperation(operator: String) {
        val num1Text = number1EditText.text.toString()
        val num2Text = number2EditText.text.toString()

        // Check for empty input fields
        if (num1Text.isEmpty() || num2Text.isEmpty()) {
            resultTextView.text = "Please enter both numbers."
            return
        }

        // Convert input text to numbers
        val num1 = num1Text.toDouble()
        val num2 = num2Text.toDouble()

        val result = when (operator) {
            "/" -> {
                if (num2 != 0.0) num1 / num2 else "Cannot divide by 0"
            }
            "*" -> num1 * num2
            "+" -> num1 + num2
            "-" -> num1 - num2
            else -> "Invalid operator"
        }

        // Display the result
        resultTextView.text = "$num1 $operator $num2 = $result"
    }

    private fun clearFields() {
        // Clear input fields and result text view
        number1EditText.text.clear()
        number2EditText.text.clear()
        resultTextView.text = ""
    }

    private fun calculateSquareRoot() {
        val num1Text = number1EditText.text.toString()

        if (num1Text.isEmpty()) {
            resultTextView.text = "Please enter a number for square root calculation."
            return
        }

        val num1 = num1Text.toDouble()
        val squareRoot: String

        if (num1 < 0) {
            // For negative numbers, calculate square root of the absolute value and add "i" for imaginary part
            val absNum1 = kotlin.math.abs(num1)
            squareRoot = "${sqrt(absNum1)}i"
        } else { 
            // For non-negative numbers, calculate real square root
            squareRoot = "${sqrt(num1)}"
        }

        resultTextView.text = "sqrt($num1) = $squareRoot"
    }

    private fun calculatePower() {
        val num1Text = number1EditText.text.toString()
        val num2Text = number2EditText.text.toString()

        // Check for empty input fields
        if (num1Text.isEmpty() || num2Text.isEmpty()) {
            resultTextView.text = "Please enter both base and exponent."
            return
        }

        // Convert input text to numbers
        val base = num1Text.toDouble()
        val exponent = num2Text.toInt()

        val result = base.pow(exponent)

        // Display the result in the format "a^b = result"
        resultTextView.text = "$base^$exponent = $result"
    }
}



